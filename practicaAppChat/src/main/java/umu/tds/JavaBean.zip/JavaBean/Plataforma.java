package umu.tds.JavaBean;

public enum Plataforma {
	IOS, ANDROID
}

